This directory stores SMALL sample PDFs for use with unit tests and
with PoDoFo's general test programs. PDFs used in examples may also
go here.

Any PDF added here must be freely redistributable under the same
license as PoDoFo its self (See README.html in the source root).
